/*
 *      Plugin Screen Saver By Youssef Eid
 *
 */


#import <UIKit/UIKit.h>

@interface @@PROJECTNAME@@Controller : UIViewController

@end
